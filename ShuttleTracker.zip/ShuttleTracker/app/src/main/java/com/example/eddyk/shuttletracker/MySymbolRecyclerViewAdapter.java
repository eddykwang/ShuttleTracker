package com.example.eddyk.shuttletracker;

import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.eddyk.shuttletracker.Symbols.SymbolContent.SymbolItem;

import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link SymbolItem} and makes a call to the
 * specified {@link SymbolFragment.OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class MySymbolRecyclerViewAdapter extends RecyclerView.Adapter<MySymbolRecyclerViewAdapter.ViewHolder> {

    private final List<SymbolItem> mValues;
    private final SymbolFragment.OnListFragmentInteractionListener mListener;

    public MySymbolRecyclerViewAdapter(List<SymbolItem> items, SymbolFragment.OnListFragmentInteractionListener listener) {
        mValues = items;
        mListener = listener;

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_symbol, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {
        holder.mItem = mValues.get(position);
        holder.mImageView.setImageResource(mValues.get(position).Image_name);
        holder.mRoutNameView.setText(mValues.get(position).rout_name);
        holder.mContentView.setText(mValues.get(position).content);

        holder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Symbol_Detail_Fragment newFragment = new Symbol_Detail_Fragment();
                Bundle args = new Bundle();
                args.putString("file_name", mValues.get(position).id);
                newFragment.setArguments(args);
                android.support.v4.app.FragmentTransaction transaction = ((FragmentActivity) (v.getContext())).getSupportFragmentManager().beginTransaction();

                transaction.setCustomAnimations( R.anim.slide_in_left, 0,0, R.anim.slide_out_left);
                transaction.replace(R.id.main_fragment, newFragment);
                transaction.addToBackStack("fragBack");

                transaction.commit();

                /*
                Bundle bundle = new Bundle();
                bundle.putString("file_name",mValues.get(position).id);
                Fragment fragment = new Symbol_Detail_Fragment();
                fragment.setArguments(bundle);

                ((FragmentActivity) (v.getContext())).getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations( R.anim.slide_in_left, 0,0, R.anim.slide_out_left)
                        .addToBackStack("fragBack")
                        .replace(R.id.main_fragment, new Symbol_Detail_Fragment()).commit();
                   */
                //if (null != mListener) {
                //    mListener.onListFragmentInteraction(holder.mItem);
                //    Toast.makeText(  v.getContext(), position + "clicked",Toast.LENGTH_LONG).show();

               // }
            }
        });
    }



    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder  {
        public final View mView;
        public final ImageView mImageView;
        public final TextView mContentView;
        public final TextView mRoutNameView;
        public SymbolItem mItem;

        public ViewHolder(View view) {
            super(view);

            mView = view;
            mImageView = (ImageView) view.findViewById(R.id.symbol_IV);
            mContentView = (TextView) view.findViewById(R.id.content);
            mRoutNameView = (TextView) view.findViewById(R.id.rout_name);

        }

        @Override
        public String toString() {
            return super.toString() + " '" + mContentView.getText() + "'";
        }


    }
}
