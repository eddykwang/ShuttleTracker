package com.example.eddyk.shuttletracker;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;

/**
 * A simple {@link Fragment} subclass.
 */
public class Map_Fragment extends Fragment {

    private View view;
    private WebView webView;

    public Map_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_map_, container, false);

        if (new MainActivity().fabShow == true) {
            new MainActivity().fab.hide();
            new MainActivity().fabShow = false;
        }
        webView = (WebView) view.findViewById(R.id.map_webview);
        String data = "<body>" + "<img src=\"ShuttleRouteMap-1.png\"/></body>";
        webView.loadDataWithBaseURL("file:///android_asset/",data , "text/html", "utf-8",null);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setBuiltInZoomControls(true);
        webView.getSettings().setDisplayZoomControls(false);
        return view;
    }

}
