package com.example.eddyk.shuttletracker;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class Symbol_Detail_Fragment extends Fragment {

    private View view;
    private WebView webView;
    private String fileNanme;

    public Symbol_Detail_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_symbol__detail_, container, false);

        Bundle bundle = this.getArguments();
        if (bundle != null){
            fileNanme = bundle.getString("file_name");
           // Toast.makeText(view.getContext(),fileNanme,Toast.LENGTH_SHORT).show();
        }

        webView = (WebView) view.findViewById(R.id.symbol_detail_wv);
        webView.loadUrl("file:///android_asset/symbol_detail/"+fileNanme+".html");
        return view;
    }

}
