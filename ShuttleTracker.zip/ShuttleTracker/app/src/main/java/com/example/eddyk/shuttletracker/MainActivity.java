package com.example.eddyk.shuttletracker;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    protected TextView warning;
    private boolean hasInternet;
    protected static FloatingActionButton fab;
    public static boolean fabShow;
    public static Context main_contex;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fab = (FloatingActionButton) findViewById(R.id.fab);
        fabShow = true;
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        main_contex = this;
        hasInternet = isOnline();
        if (hasInternet){
            if (savedInstanceState == null) {
                MenuItem item = navigationView.getMenu().getItem(0);
                onOptionsItemSelected(item);
                onNavigationItemSelected(item);
            }
        }
        else{
            warning = (TextView) findViewById(R.id.warning_text);
            warning.setText("Please check internet connection!");
            Toast.makeText(this,"No Internet", Toast.LENGTH_LONG).show();
        }
    }



    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null &&
                cm.getActiveNetworkInfo().isConnectedOrConnecting();
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            if(Main_Fragment.canGoBack()){
                Main_Fragment.goBack();
            }else{
                super.onBackPressed();
            }
        }


    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {

                getSupportFragmentManager().beginTransaction().replace(R.id.main_fragment, new Main_Fragment()).commit();
                getSupportActionBar().setTitle(item.getTitle());

        } else if (id == R.id.nav_map) {
                 getSupportFragmentManager().beginTransaction().addToBackStack("fragBack").replace(R.id.main_fragment, new Map_Fragment()).commit();
                 getSupportActionBar().setTitle(item.getTitle());
        } else if (id == R.id.nav_sign) {
                 getSupportFragmentManager().beginTransaction().addToBackStack("fragBack").replace(R.id.main_fragment, new SymbolFragment()).commit();
                 getSupportActionBar().setTitle(item.getTitle());

        } else if (id == R.id.nav_call) {

            new AlertDialog.Builder(main_contex)
                    .setTitle("Call office")
                    .setMessage("Are you sure you want to call the office?")
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {

                            String number = "8585347422";
                            Intent intent = new Intent(Intent.ACTION_CALL);
                            intent.setData(Uri.parse("tel:" +number));
                            startActivity(intent);
                        }
                    })
                    .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            // do nothing
                        }
                    })
                    .setIcon(android.R.drawable.ic_menu_call)
                    .show();


        } else if (id == R.id.nav_share) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, "Download the UCSD Shuttle Tracker to track bus in real time!");
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
        } else if (id == R.id.nav_about) {
            Intent intent = new Intent(this, About_Activity.class);
            startActivity(intent);
        } else if (id == R.id.nav_facebook){
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/UCSanDiegoShuttles/"));
            startActivity(browserIntent);
        } else if (id == R.id.nav_twitter){
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/shuttlesocial"));
            startActivity(browserIntent);
        } else{
            Toast.makeText(this,"Error, Please contact the developer!", Toast.LENGTH_LONG).show();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
