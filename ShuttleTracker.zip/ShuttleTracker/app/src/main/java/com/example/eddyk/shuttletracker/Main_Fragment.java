package com.example.eddyk.shuttletracker;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

/**
 * A simple {@link Fragment} subclass.
 */
public class Main_Fragment extends Fragment{

    private View view;
    private static WebView webView;
    private ProgressBar pb;

    public Main_Fragment() {
        // Required empty public constructor
    }

    public class GeoWebChromeClient extends WebChromeClient {
        @Override
        public void onGeolocationPermissionsShowPrompt(String origin,
                                                       GeolocationPermissions.Callback callback) {
            // Always grant permission since the app itself requires location
            // permission and the user has therefore already granted it
            callback.invoke(origin, true, false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view =  inflater.inflate(R.layout.fragment_main_, container, false);

        MainActivity ma = new MainActivity();

        if (ma.fabShow == false){
           // ma.fab = (FloatingActionButton) view.findViewById(R.id.fab);
            ma.fab.show();
            ma.fabShow = true;
        }

        ma.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reloadPage();
                Snackbar.make(view, "Refreshing...", Snackbar.LENGTH_SHORT)
                        .setAction("Action", null).show();
            }
        });

        webView = (WebView) view.findViewById(R.id.main_fragment_wv);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.setWebChromeClient(new GeoWebChromeClient());
        String  url ="http://www.ucsdbus.com/m/routes";
        load_web(url);

        return view;
    }

    public static boolean canGoBack() {
        return webView.canGoBack();
    }

    public static void goBack() {
        webView.goBack();
    }

    public void load_web(String url){

        webView.loadUrl(url);
        loading();

    }

    public void loading(){
        pb = (ProgressBar) view.findViewById(R.id.progressBar);
        pb.setProgress(0);
        pb.setVisibility(View.VISIBLE);
        webView.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageFinished(WebView view, String url) {
                    pb.setVisibility(View.GONE);
                    pb.setProgress(100);

            }
        });
    }
    public void reloadPage(){
      //  hasInternet = false;
        webView.reload();
        loading();
    }


}
